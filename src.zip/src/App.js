import './App.css';
import {Link} from 'react-router-dom';

function App() {
  return (
    <div >
    <button>
      <Link to="/typing">Proceed To Game</Link>
    </button>
    </div>
  );
}

export default App;
